# Turing Wire ©
