---
title: "GlobalFoundries"
layout: company
---
